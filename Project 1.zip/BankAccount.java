public class BankAccount {
    private int accountNumber;
    private int pin;
    private String name;
    private double currentBalance;

    public BankAccount(int accountNumber, int pin, String name, double currentBalance) {
        this.accountNumber = accountNumber;
        this.pin = pin;
        this.name = name;
        this.currentBalance = currentBalance;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public String getName() {
        return name;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            currentBalance += amount;
            System.out.printf("Successfully deposited $%.2f\n", amount);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0 && currentBalance >= amount) {
            currentBalance -= amount;
            System.out.printf("Successfully withdrew $%.2f\n", amount);
        } else if (amount > currentBalance) {
            System.out.println("Insufficient funds.");
        } else {
            System.out.println("Invalid withdrawal amount.");
        }
    }

    public void checkBalance() {
        System.out.printf("Current Balance: $%.2f\n", currentBalance);
    }

    public boolean validatePin(int inputPin) {
        return this.pin == inputPin;
    }
}