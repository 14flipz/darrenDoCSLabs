import java.util.Scanner;

public class Exercise {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Bank bank = new Bank();

        System.out.println("Welcome to the Bank!");
        System.out.print("Enter your Account Number: ");
        int accNum = scanner.nextInt();
        
        System.out.print("Enter your PIN: ");
        int pin = scanner.nextInt();

        BankAccount activeAccount = bank.findAccount(accNum, pin);

        if (activeAccount != null) {
            System.out.println("\nWelcome, " + activeAccount.getName() + "!");
            bank.performTransaction(activeAccount, scanner);
        } else {
            System.out.println("Login failed. Exiting application.");
        }

        scanner.close();
    }
}