import java.util.ArrayList;
import java.util.Scanner;

public class Bank {
    private ArrayList<BankAccount> accounts;

    public Bank() {
        accounts = new ArrayList<>();
        accounts.add(new BankAccount(1001, 1234, "John Doe", 500.00));
        accounts.add(new BankAccount(1002, 2345, "Jane Smith", 1200.00));
        accounts.add(new BankAccount(1003, 3456, "Alice Johnson", 850.00));
    }

    public BankAccount findAccount(int accountNumber, int pin) {
        for (BankAccount account : accounts) {
            if (account.getAccountNumber() == accountNumber) {
                if (account.validatePin(pin)) {
                    return account;
                } else {
                    System.out.println("Incorrect PIN.");
                    return null;
                }
            }
        }
        System.out.println("Account not found.");
        return null;
    }

    public void performTransaction(BankAccount account, Scanner scanner) {
        boolean running = true;

        while (running) {
            System.out.println("\n--- Transaction Menu ---");
            System.out.println("1. Check Balance");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    account.checkBalance();
                    break;
                case 2:
                    System.out.print("Enter deposit amount: $");
                    double depAmount = scanner.nextDouble();
                    account.deposit(depAmount);
                    break;
                case 3:
                    System.out.print("Enter withdrawal amount: $");
                    double withAmount = scanner.nextDouble();
                    account.withdraw(withAmount);
                    break;
                case 4:
                    System.out.println("Thank you for using our bank. Goodbye!");
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }

            if (running) {
                System.out.print("\nWould you like to do another transaction? (y/n): ");
                String continueTrans = scanner.next();
                if (!continueTrans.equalsIgnoreCase("y")) {
                    System.out.println("Thank you for using our bank. Goodbye!");
                    running = false;
                }
            }
        }
    }
}